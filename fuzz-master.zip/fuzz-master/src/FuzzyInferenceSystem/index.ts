export { FuzzyInferenceSystem } from './FuzzyInferenceSystem';
export * from './types';
