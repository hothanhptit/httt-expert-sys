export { DefuzzicationType } from './types';
export * from './defuzzify';
