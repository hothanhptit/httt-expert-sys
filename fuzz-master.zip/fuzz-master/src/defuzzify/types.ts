export enum DefuzzicationType {
  'Centroid' = 'Centroid',
  'MeanOfMaxima' = 'MeanOfMaxima',
  'SmallestOfMaxima' = 'SmallestOfMaxima',
  'LargestOfMaxima' = 'LargestOfMaxima',
}
